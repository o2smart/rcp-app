
# RCP App O2Smart

Este é o projeto Flutter do app educacional "RCP App O2Smart", com foco em simulação de parada cardiorrespiratória.

## Requisitos
- Flutter SDK
- Android SDK ou uso de plataforma de build como Codemagic

## Como compilar com Codemagic
Siga o guia incluso no arquivo "Guia_Codemagic_PT.txt".
